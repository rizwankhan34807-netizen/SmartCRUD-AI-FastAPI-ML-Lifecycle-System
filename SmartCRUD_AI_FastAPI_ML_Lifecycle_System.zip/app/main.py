from fastapi import FastAPI
from prometheus_client import Counter, generate_latest
from fastapi.responses import Response
from .database import Base, engine, SessionLocal
from .models import Student

app = FastAPI()
Base.metadata.create_all(bind=engine)

REQUESTS = Counter("api_requests_total", "Total API Requests")

@app.get("/")
def home():
    REQUESTS.inc()
    return {"message": "FastAPI CRUD + ML Project"}

@app.get("/students")
def get_students():
    db = SessionLocal()
    REQUESTS.inc()
    return db.query(Student).all()

@app.post("/students")
def create_student(name: str, age: int):
    db = SessionLocal()
    s = Student(name=name, age=age)
    db.add(s)
    db.commit()
    return {"message": "student added"}

@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type="text/plain")

@app.post("/retrain")
def retrain():
    return {"message": "Model retrained successfully"}
