# Beginner FastAPI CRUD + ML Lifecycle Project

Features:
- FastAPI CRUD API
- SQLite database (easy beginner setup; can be replaced with MySQL)
- Simple ML model training
- Prometheus metrics endpoint
- Retraining endpoint

Run:
pip install -r requirements.txt
uvicorn app.main:app --reload
